module.exports=[61186,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_shuoshuo_page_actions_14a5s0h4guzqy.js.map