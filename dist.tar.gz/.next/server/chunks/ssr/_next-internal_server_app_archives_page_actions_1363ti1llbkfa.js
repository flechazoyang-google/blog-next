module.exports=[9431,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_archives_page_actions_1363ti1llbkfa.js.map