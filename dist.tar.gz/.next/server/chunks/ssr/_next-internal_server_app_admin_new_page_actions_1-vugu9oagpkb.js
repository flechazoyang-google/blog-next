module.exports=[78235,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_new_page_actions_1-vugu9oagpkb.js.map