module.exports=[39731,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_totp_cancel_route_actions_0a-nfsilqqec8.js.map