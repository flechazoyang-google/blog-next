module.exports=[25535,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_admin_posts_%5Bid%5D_restore_route_actions_0-ap41dcjv70w.js.map