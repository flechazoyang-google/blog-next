module.exports=[23850,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_media_%5Bid%5D_route_actions_119i6ewt0v6_u.js.map