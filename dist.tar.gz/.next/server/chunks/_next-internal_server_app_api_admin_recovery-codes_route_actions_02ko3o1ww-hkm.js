module.exports=[90401,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_recovery-codes_route_actions_02ko3o1ww-hkm.js.map