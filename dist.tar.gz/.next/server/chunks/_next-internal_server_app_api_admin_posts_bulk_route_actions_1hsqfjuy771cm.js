module.exports=[63935,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_posts_bulk_route_actions_1hsqfjuy771cm.js.map