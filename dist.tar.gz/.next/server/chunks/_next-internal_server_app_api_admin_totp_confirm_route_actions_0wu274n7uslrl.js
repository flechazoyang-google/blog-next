module.exports=[96514,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_totp_confirm_route_actions_0wu274n7uslrl.js.map