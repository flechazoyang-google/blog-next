:HL["/_next/static/chunks/23xb9uqlqepxc.css","style"]
3:[["children",{"s":"__PAGE__","h":160}]]
2:[["children",{"s":"login","h":96,"c":"$Q3"}]]
1:[["children",{"s":"admin","h":96,"c":"$Q2"}]]
0:{"b":"A05f81QfJcM8OskVW1bKS","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
