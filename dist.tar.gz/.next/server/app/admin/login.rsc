1:"$Sreact.fragment"
2:"/_next/static/chunks/11330s1h4er4b.js"
3:I[24691,["$2"],"ScrollReset"]
4:I[32119,["$2"],"MobileNav"]
5:I[39756,["$2"],"default"]
6:I[37457,["$2"],"default"]
7:I[22016,["$2"],""]
8:I[64576,["$2"],"PwaRegister"]
d:I[47257,["$2"],"ClientPageRoot"]
e:"/_next/static/chunks/1obo4hf4437b6.js"
f:I[7156,["$2","$e"],"default"]
12:I[97367,["$2"],"OutletBoundary"]
13:"$Sreact.suspense"
15:"ViewportBoundary"
16:I[97367,["$2"],"$15"]
18:"MetadataBoundary"
19:I[97367,["$2"],"$18"]
1b:I[68027,["$2"],"default",1]
:HL["/_next/static/chunks/23xb9uqlqepxc.css","style"]
a:X
c:[["children",{"s":"__PAGE__","h":512,"d":{"r":["$","$1","c",{"children":[["$","$Ld",null,{"Component":"$f","serverProvidedParams":{"searchParams":{},"params":{},"promises":["$@10","$@11"]}}],[["$","script","script-0",{"src":"/_next/static/chunks/1obo4hf4437b6.js","async":true,"nonce":"$undefined"}]],["$","$L12",null,{"children":["$","$13",null,{"name":"Next.MetadataOutlet","children":"$@14"}]}]]}],"p":false,"v":null}}]]
b:[["children",{"s":"login","h":512,"d":{"r":["$","$1","c",{"children":[null,["$","$L5",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L6",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":false,"v":"$a"},"c":"$Qc"}]]
9:[["children",{"s":"admin","h":512,"d":{"r":["$","$1","c",{"children":[null,["$","$L5",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L6",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":false,"v":"$a"},"c":"$Qb"}]]
0:{"P":null,"c":["","admin","login"],"q":"","i":false,"t":{"t":{"s":"","h":528,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/23xb9uqlqepxc.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/11330s1h4er4b.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"zh-CN","children":["$","body",null,{"children":[["$","$L3",null,{}],["$","$L4",null,{}],["$","$L5",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L6",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","div",null,{"style":{"maxWidth":480,"margin":"20vh auto","padding":"0 24px","textAlign":"center"},"children":[["$","h1",null,{"style":{"fontFamily":"var(--font-serif)","fontSize":"2.5rem","color":"var(--text-p0)","margin":"0 0 12px"},"children":"404"}],["$","p",null,{"style":{"color":"var(--text-p3)","marginBottom":24},"children":"这个页面不存在"}],["$","$L7",null,{"href":"/","className":"btn","children":"回到首页"}]]}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}],null,["$","$L8",null,{}]]}]}]]}],"p":false,"v":null},"c":"$Q9"},"h":{"r":["$","$1","h",{"children":[null,["$","$L16",null,{"children":"$L17"}],["$","$L19",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$13",null,{"name":"Next.Metadata","children":"$L1a"}]}],null]}],null]}],"p":false,"v":null}},"m":"$undefined","G":["$1b",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/23xb9uqlqepxc.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"r":"$undefined","s":"$undefined","a":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"2cMYJA8c3pSaBDUjN0dNn"}
a:C
10:{}
11:"$c:0:1:d:r:props:children:0:props:serverProvidedParams:params"
17:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1, maximum-scale=5, viewport-fit=cover"}],["$","meta","2",{"name":"theme-color","content":"#fffefc"}]]
1c:I[27201,["$2"],"IconMark"]
14:null
1a:[["$","title","0",{"children":"flechazo's blog"}],["$","meta","1",{"name":"description","content":"记录 AI、开发与折腾的日常。"}],["$","meta","2",{"name":"application-name","content":"flechazo's blog"}],["$","link","3",{"rel":"manifest","href":"/manifest.webmanifest","crossOrigin":"$undefined"}],["$","meta","4",{"name":"format-detection","content":"telephone=no"}],["$","meta","5",{"name":"mobile-web-app-capable","content":"yes"}],["$","meta","6",{"name":"apple-mobile-web-app-title","content":"flechazo"}],["$","meta","7",{"name":"apple-mobile-web-app-status-bar-style","content":"default"}],["$","meta","8",{"property":"og:title","content":"flechazo's blog"}],["$","meta","9",{"property":"og:description","content":"记录 AI、开发与折腾的日常。"}],["$","meta","10",{"property":"og:site_name","content":"flechazo's blog"}],["$","meta","11",{"property":"og:locale","content":"zh_CN"}],["$","meta","12",{"property":"og:type","content":"website"}],["$","meta","13",{"name":"twitter:card","content":"summary_large_image"}],["$","meta","14",{"name":"twitter:title","content":"flechazo's blog"}],["$","meta","15",{"name":"twitter:description","content":"记录 AI、开发与折腾的日常。"}],["$","link","16",{"rel":"icon","href":"/favicon-32.png","sizes":"32x32","type":"image/png"}],["$","link","17",{"rel":"icon","href":"/favicon-16.png","sizes":"16x16","type":"image/png"}],["$","link","18",{"rel":"icon","href":"/icon-192.png","sizes":"192x192","type":"image/png"}],["$","link","19",{"rel":"apple-touch-icon","href":"/apple-touch-icon.png","sizes":"180x180"}],["$","$L1c","20",{}]]
