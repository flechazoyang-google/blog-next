var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/healthz/route.js")
R.c("server/chunks/[root-of-the-server]__18-2wr5m4cued._.js")
R.c("server/chunks/lib_db_ts_1ttuckbd3em8v._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/node_modules_next_0sx6ib_cz483a._.js")
R.c("server/chunks/_1o9k9xokn05x_._.js")
R.c("server/chunks/_next-internal_server_app_api_healthz_route_actions_1oibm89vut68q.js")
R.m(74316)
module.exports=R.m(74316).exports
