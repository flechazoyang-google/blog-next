:HL["/_next/static/chunks/23xb9uqlqepxc.css","style"]
2:[["children",{"s":"__PAGE__","h":160}]]
1:[["children",{"s":"/_not-found","h":96,"c":"$Q2"}]]
0:{"b":"A05f81QfJcM8OskVW1bKS","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
