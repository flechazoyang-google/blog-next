var R=require("../../chunks/[turbopack]_runtime.js")("server/app/manifest.webmanifest/route.js")
R.c("server/chunks/[externals]__0umxrut1jp3dl._.js")
R.c("server/chunks/node_modules_next_dist_16uekqf-emgzs._.js")
R.c("server/chunks/node_modules_next_0sx6ib_cz483a._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5yieigz._.js")
R.c("server/chunks/_10i2t-26x3leb._.js")
R.c("server/chunks/_next-internal_server_app_manifest_webmanifest_route_actions_08hcpz02cjxld.js")
R.m(37648)
module.exports=R.m(37648).exports
