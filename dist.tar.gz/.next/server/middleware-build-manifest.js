globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/mOTcvwRQMaIvppDMBMtxG/_buildManifest.js",
    "static/mOTcvwRQMaIvppDMBMtxG/_ssgManifest.js",
    "static/mOTcvwRQMaIvppDMBMtxG/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1x6obpmlu1_c2.js",
    "static/chunks/1-nqmp1rl8kqt.js",
    "static/chunks/2khxl0v1q4i6n.js",
    "static/chunks/0-_5ufntft2if.js",
    "static/chunks/turbopack-3-ry682tkyiqk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/2khxl0v1q4i6n.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/2khxl0v1q4i6n.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/2khxl0v1q4i6n.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/[slug]/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/2khxl0v1q4i6n.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/2khxl0v1q4i6n.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/audit/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/2khxl0v1q4i6n.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/comments/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/2khxl0v1q4i6n.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/edit/[id]/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/2khxl0v1q4i6n.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/login/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/2khxl0v1q4i6n.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/media/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/2khxl0v1q4i6n.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/new/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/2khxl0v1q4i6n.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/settings/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/2khxl0v1q4i6n.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/archives/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/2khxl0v1q4i6n.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/search/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/2khxl0v1q4i6n.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/shuoshuo/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/2khxl0v1q4i6n.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/tags/[tag]/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/2khxl0v1q4i6n.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
