globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/U69FTHZFxvW1-MaNFXkjs/_buildManifest.js",
    "static/U69FTHZFxvW1-MaNFXkjs/_ssgManifest.js",
    "static/U69FTHZFxvW1-MaNFXkjs/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1kexj4s7oxhs2.js",
    "static/chunks/1-nqmp1rl8kqt.js",
    "static/chunks/0psvc2-xx4oyr.js",
    "static/chunks/0-_5ufntft2if.js",
    "static/chunks/turbopack-3-ry682tkyiqk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/1kexj4s7oxhs2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/0psvc2-xx4oyr.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/1kexj4s7oxhs2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/0psvc2-xx4oyr.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/1kexj4s7oxhs2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/0psvc2-xx4oyr.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/[slug]/page": {
      "otherChunks": [
        "static/chunks/1kexj4s7oxhs2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/0psvc2-xx4oyr.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/page": {
      "otherChunks": [
        "static/chunks/1kexj4s7oxhs2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/0psvc2-xx4oyr.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/audit/page": {
      "otherChunks": [
        "static/chunks/1kexj4s7oxhs2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/0psvc2-xx4oyr.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/comments/page": {
      "otherChunks": [
        "static/chunks/1kexj4s7oxhs2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/0psvc2-xx4oyr.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/edit/[id]/page": {
      "otherChunks": [
        "static/chunks/1kexj4s7oxhs2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/0psvc2-xx4oyr.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/login/page": {
      "otherChunks": [
        "static/chunks/1kexj4s7oxhs2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/0psvc2-xx4oyr.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/media/page": {
      "otherChunks": [
        "static/chunks/1kexj4s7oxhs2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/0psvc2-xx4oyr.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/new/page": {
      "otherChunks": [
        "static/chunks/1kexj4s7oxhs2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/0psvc2-xx4oyr.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/admin/settings/page": {
      "otherChunks": [
        "static/chunks/1kexj4s7oxhs2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/0psvc2-xx4oyr.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/archives/page": {
      "otherChunks": [
        "static/chunks/1kexj4s7oxhs2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/0psvc2-xx4oyr.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/search/page": {
      "otherChunks": [
        "static/chunks/1kexj4s7oxhs2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/0psvc2-xx4oyr.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/shuoshuo/page": {
      "otherChunks": [
        "static/chunks/1kexj4s7oxhs2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/0psvc2-xx4oyr.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/tags/[tag]/page": {
      "otherChunks": [
        "static/chunks/1kexj4s7oxhs2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/0psvc2-xx4oyr.js",
        "static/chunks/0-_5ufntft2if.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
